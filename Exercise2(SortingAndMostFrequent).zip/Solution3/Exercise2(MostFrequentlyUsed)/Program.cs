﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Exercise2_MostFrequentlyUsed_
{
	class Program
	{
		static void Main(string[] args)
		{
			int[] numbers = new int[] { 4, 1, 1, 4, 1, 2, 4, 4, 1, 2, 4, 9, 3 };

			int[] count = new int[numbers.Length];

			int base1 = 0;

			for (int i = 0; i < numbers.Length; i++)
			{
				count[i] = numbers[i];
			}

			for (int i = 0; i < numbers.Length; i++)
			{
				int counter = 0;

				for (int j = 0; j < (numbers.Length); j++)
				{
					if (numbers[base1] == numbers[j])
					{
						counter++;
					}
				}
				count[base1] = counter;

				base1++;

			}

			Console.WriteLine("The most frequently used number is " + numbers[Array.IndexOf(count, count.Max())] + " counted " + count.Max() + " times.");
			Console.Read();
		}
	}
}

