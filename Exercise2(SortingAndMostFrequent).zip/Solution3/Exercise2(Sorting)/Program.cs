﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Exercise2_Sorting_
{
	class Program
	{
		static void Main(string[] args)
		{
			while (true)
			{
				int[] numbers = new int[10];
				int temp = 0;

				Console.WriteLine("Sorting");

				for (int i = 0; i < 10; i++)
				{

					Console.Write("Number " + (i + 1) + ": ");
					string input = Console.ReadLine();
					numbers[i] = int.Parse(input);

				}

				for (int i = 0; i < numbers.Length - 1; i++)
				{

					for (int j = 0; j < numbers.Length - 1; j++)
					{
						if (numbers[j] > numbers[j + 1])
						{
							temp = numbers[j];
							numbers[j] = numbers[j + 1];
							numbers[j + 1] = temp;

						}
					}

				}

				for (int i = 0; i < numbers.Length; i++)
				{
					Console.Write(numbers[i] + ",");
				}

				Console.WriteLine();

				Console.WriteLine();
			}
		}
	}
}
