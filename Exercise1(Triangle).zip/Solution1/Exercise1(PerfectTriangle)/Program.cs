﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Exercise1_PerfectTriangle_
{
	class Program
	{
		static void Main(string[] args)
		{
			while (true)
			{
				Console.Write("Enter number: ");
				string input = Console.ReadLine();
				int number = int.Parse(input);
				int number2 = number;

				if (number < 3)
				{
					Console.WriteLine("Minimum number is 3");
				}
				else
				{

					for (int i = 0; i < number; i++)
					{
						for (int j = number2; j > 0; j--)
						{
							Console.Write(" ");
						}
						for (int k = 0; k <= i; k++)
						{
							Console.Write("* ");
						}
						Console.WriteLine();
						number2--;
					}
				}
				Console.WriteLine();
			}
		}
	}
}
