﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CalculatorOOP
{
	class ConvertToDouble
	{
		public static double Convert(string input)
		{
			return double.Parse(input);
		}
	}
}
