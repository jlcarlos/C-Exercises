﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CalculatorOOP
{
	class Division
	{
		public static double Divide(string num1, string num2)
		{
			double input1 = ConvertToDouble.Convert(num1);
			double input2 = ConvertToDouble.Convert(num2);
			double answer = input1 / input2;
			return answer;
		}
	}
}
