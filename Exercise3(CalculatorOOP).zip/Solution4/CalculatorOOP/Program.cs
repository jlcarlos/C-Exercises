﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CalculatorOOP
{
	class Program
	{
		static void Main(string[] args)
		{
			int input = ReturnInput.Return();
			Console.Write("Enter first number: ");
			string input1 = Console.ReadLine();
			Console.Write("Enter second number: ");
			string input2 = Console.ReadLine();
			double answer;

			while (true)
			{
				if (input == 1)
				{
					answer = Addition.Add(input1, input2);
					Console.WriteLine("Add, The answer is " + answer);
					input = ReturnInput.Return();
					input1 = answer.ToString();
					Console.WriteLine("First number: " + input1);
					input2 = ReturnInput2.Return();

				}
				else if (input == 2)
				{
					answer = Subtraction.Subtract(input1, input2);
					Console.WriteLine("Subtract, The answer is " + answer);
					input = ReturnInput.Return();
					input1 = answer.ToString();
					Console.WriteLine("First number: " + input1);
					input2 = ReturnInput2.Return();

				}
				else if (input == 3)
				{
					answer = Multiplication.Multiply(input1, input2);
					Console.WriteLine("Multiply, The answer is " + answer);
					input = ReturnInput.Return();
					input1 = answer.ToString();
					Console.WriteLine("First number: " + input1);
					input2 = ReturnInput2.Return();

				}
				else if (input == 4)
				{
					answer = Division.Divide(input1, input2);
					Console.WriteLine("Divide, The answer is " + answer);
					input = ReturnInput.Return();
					input1 = answer.ToString();
					Console.WriteLine("First number: " + input1);
					input2 = ReturnInput2.Return();

				}
			}
		}
	}
}
