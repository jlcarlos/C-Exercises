﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CalculatorOOP
{
	class ReturnInput2
	{
		public static string Return()
		{
			Console.Write("Enter second number: ");
			string input2 = Console.ReadLine();
			return input2;
		}
	}
}
