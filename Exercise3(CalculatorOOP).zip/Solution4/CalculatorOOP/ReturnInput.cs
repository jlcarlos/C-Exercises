﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CalculatorOOP
{
	class ReturnInput
	{
		public static int Return()
		{
			Console.Write("Press (1)Addition, (2)Subtraction, (3)Multiplication, (4)Division: ");
			int input = int.Parse(Console.ReadLine());
			return input;
		}
		
	}
}
