﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Exercise2_Calculator_
{
	class Program
	{
		static void Main(string[] args)
		{
			int input = ReturnInput();
			Console.Write("Enter first number: ");
			string input1 = Console.ReadLine();
			Console.Write("Enter second number: ");
			string input2 = Console.ReadLine();
			double answer;

			while (true)
			{
				if (input == 1)
				{
					answer = Addition(input1, input2);
					Console.WriteLine("Add, The answer is " + answer);
					input = ReturnInput();
					input1 = answer.ToString();
					Console.WriteLine("First number: " + input1);
					input2 = ReturnInput2();

				}
				else if (input == 2)
				{
					answer = Subtraction(input1, input2);
					Console.WriteLine("Subtract, The answer is " + answer);
					input = ReturnInput();
					input1 = answer.ToString();
					Console.WriteLine("First number: " + input1);
					input2 = ReturnInput2();

				}
				else if (input == 3)
				{
					answer = Multiplication(input1, input2);
					Console.WriteLine("Multiply, The answer is " + answer);
					input = ReturnInput();
					input1 = answer.ToString();
					Console.WriteLine("First number: " + input1);
					input2 = ReturnInput2();

				}
				else if (input == 4)
				{
					answer = Division(input1, input2);
					Console.WriteLine("Divide, The answer is " + answer);
					input = ReturnInput();
					input1 = answer.ToString();
					Console.WriteLine("First number: " + input1);
					input2 = ReturnInput2();

				}


			}

		}
		static int ReturnInput()
		{
			Console.Write("Press (1)Addition, (2)Subtraction, (3)Multiplication, (4)Division: ");
			int input = int.Parse(Console.ReadLine());
			return input;
		}
		static string ReturnInput2()
		{
			Console.Write("Enter second number: ");
			string input2 = Console.ReadLine();
			return input2;
		}
		static double ConvertToDouble(string input)
		{
			return double.Parse(input);
		}

		static double Addition(string num1, string num2)
		{
			double input1 = ConvertToDouble(num1);
			double input2 = ConvertToDouble(num2);
			double answer = input1 + input2;
			return answer;
		}
		static double Subtraction(string num1, string num2)
		{
			double input1 = ConvertToDouble(num1);
			double input2 = ConvertToDouble(num2);
			double answer = input1 - input2;
			return answer;
		}
		static double Multiplication(string num1, string num2)
		{
			double input1 = ConvertToDouble(num1);
			double input2 = ConvertToDouble(num2);
			double answer = input1 * input2;
			return answer;
		}
		static double Division(string num1, string num2)
		{
			double input1 = ConvertToDouble(num1);
			double input2 = ConvertToDouble(num2);
			double answer = input1 / input2;
			return answer;
		}
	}
}
